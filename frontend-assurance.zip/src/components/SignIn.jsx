
import React, { useState } from 'react';
import logo from '../assets/assurance.ico';
import welcome from '../assets/welcomeBack.png';
import eye from '../assets/eye.png';
import eyeSlash from '../assets/eye-slash.jpg';

const SignIn = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Email: ${email}\nPassword: ${password}`);
  };

  return (
    <div className="w-[840px] h-[1024px] relative mx-auto border shadow-lg bg-white">
      <img src={logo} alt="Logo" className="absolute" style={{ top: '104px', left: '322px', width: '175px', height: '130px' }} />
      <img src={welcome} alt="Welcome Back" className="absolute left-1/2" style={{ top: '250px', transform: 'translateX(-50%)', width: '383px', height: '53.63px' }} />
      <p className="absolute left-1/2 text-center text-[16px] font-normal font-lato" style={{ top: '310px', transform: 'translateX(-50%)', width: '375px', height: '19px', lineHeight: '16px', letterSpacing: '0px', color: '#898E97' }}>
        Welcome back ! Please enter your details to continue.
      </p>
      <div className="absolute top-[370px] left-1/2 -translate-x-1/2 p-8 rounded w-[580px]">
        <form onSubmit={handleSubmit}>
          <div className="flex flex-col gap-[10px] mb-6" style={{ width: '580px', height: '87px' }}>
            <label className="text-[#000000] font-lato font-normal" style={{ width: '580px', height: '27px', fontSize: '16px', lineHeight: '27px' }}>
              Email address
            </label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="px-4 border border-[#C4C4C4] rounded-[10px] font-lato" style={{ width: '580px', height: '56px', fontSize: '16px' }} />
          </div>
          <div className="flex flex-col gap-[4px] mb-2" style={{ width: '580px', height: '87px' }}>
            <div className="flex justify-between items-center" style={{ width: '100%' }}>
              <label className="text-[#000000] font-lato font-normal" style={{ height: '27px', fontSize: '16px', lineHeight: '27px' }}>Password</label>
              <div className="flex items-center gap-2 cursor-pointer" onClick={() => setShowPassword(!showPassword)}>
                <img src={showPassword ? eye : eyeSlash} alt="toggle-visibility" style={{ width: '24px', height: '24px' }} />
                <span className="rounded px-2" style={{ color: '#666666CC', fontFamily: 'Lato', fontWeight: 400, fontSize: '18px', height: '22px', lineHeight: '18px', display: 'flex', alignItems: 'center' }}>
                  {showPassword ? 'Show' : 'Hide'}
                </span>
              </div>
            </div>
            <input type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} required className="px-4 border border-[#C4C4C4] rounded-[10px] font-lato" style={{ width: '580px', height: '56px', fontSize: '16px' }} />
          </div>
          <div style={{ width: '580px', marginBottom: '1.5rem' }}>
            <p className="font-inter font-normal text-[16px]" style={{ width: '140px', height: '19px', lineHeight: '16px', letterSpacing: '0px', color: '#477EFF', cursor: 'pointer' }}>
              Forget Password ?
            </p>
          </div>
          <button type="submit" className="bg-blue-500 text-white rounded-[10px] hover:bg-blue-600 mx-auto block" style={{ width: '360px', height: '45px', paddingTop: '10px', paddingBottom: '10px', paddingLeft: '15px', paddingRight: '15px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '23px', fontSize: '16px', fontWeight: '600', cursor: 'pointer' }}>
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
};

export default SignIn;
